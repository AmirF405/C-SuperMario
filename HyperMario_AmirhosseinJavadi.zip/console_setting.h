#ifndef CONSOLE_SETTING_H
#define CONSOLE_SETTING_H

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>




void setConsoleSizeAndLockLOGIN();


void setConsoleSizeAndLockGAME();




#endif 


